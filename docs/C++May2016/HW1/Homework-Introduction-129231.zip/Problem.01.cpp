#include "stdafx.h"
#include <iostream>
#include <map>
#include <string>
#include <ctype.h>
#include <locale>
#include <windows.h>

using namespace std;

string ConvertToUFT(string normalString)
{
	char buf[1000000];
	OemToCharA(normalString.c_str(), buf); // windows.h
	return buf;
}
int main()
{
	setlocale(LC_ALL, "bulgarian");
	
	string input = "";
	
	cout << "Please, input string !"<<endl;
	getline(std::cin, input);
	
	input = ConvertToUFT(input);

	int upperLettersCount = 0;
	int lowerLettersCount = 0;
	int othersCount = 0;

	unsigned int len = input.length();
	for (unsigned int i = 0; i<len; i++)
	{
		if (islower(input[i]))
		{
			lowerLettersCount++;
		}
		else if (isupper(input[i]))
		{
			upperLettersCount++;
		}
		else
		{
			othersCount++;
		}
	}

	std::cout << std::endl << "Uppers letters in string: " <<input<< " are: " <<upperLettersCount << std::endl;
	std::cout << std::endl << "Lowers letters in string: " << input << " are: " << lowerLettersCount << std::endl;
	std::cout << std::endl << "Other letters in string: " << input << " are: " << othersCount << std::endl;
	return 0;
}