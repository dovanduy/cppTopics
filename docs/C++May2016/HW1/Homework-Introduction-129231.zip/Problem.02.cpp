#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

void printChar(char aCharacter)
{
	cout << aCharacter << endl;
}

int sum(int a, int b) 
{ 
	return a + b; 
}

unsigned short checkAge(unsigned short age) 
{
	if (age < 12) return 0;
	else if (age < 18)  return 1;
	else return 2;
}

int main()
{
	cout << "Enter character!";
	char aCharacter;
	cin >> aCharacter;
	printChar(aCharacter);

	int a;
	int b;
	cout << "Please enter two integers!";
	cin >> a >> b;
	int result = sum(a, b);

	cout << "The result from a and b is: " << result << endl;

	cout << "Please enter age!" << endl;
	unsigned int inputAge;
	cin >> inputAge;
	unsigned int age = checkAge(inputAge);
	switch (age)
	{
	case 0:
		cout << "Under 12" << endl;
			break;
	case 1:
		cout << "More 12, under 18" << endl;
		break;
	case 2:
		cout << "More then 17" << endl;
		break;
	default:
		break;
	}
	
	string myString;
	cout << "Input string" << endl;
	cin.ignore();
	getline( cin, myString);
	cout << "The symbols in string: " << myString << " are: " << myString.length() << endl;
}

