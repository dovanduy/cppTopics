#include <iostream>
#include <string>

using namespace std;

int main()
{
	cout << "Enter name: ";
	string name;
	getline(cin, name);

	cout << "Enter age: ";
	int age;
	cin >> age;

	int letterCount = 0;

	int i = 0;
	while (name[i])
	{
		letterCount++;
		i++;
	}

	if (age > 18)
	{
		cout << "Would you like beer or whiskey? ";
		string beverage;
		cin >> beverage;

		if (beverage == "whiskey")
		{
			cout << "Good choice" << endl;
		}
		else if (beverage == "beer")
		{
			cout << "Yuk!" << endl;
		}
		else cout << "Not available" << endl;
	}
	else
	{
		cout << "Go to bed!" << endl;
	}


	cout << "Your name has: " << letterCount << " letters" << endl;

	return 0;
}