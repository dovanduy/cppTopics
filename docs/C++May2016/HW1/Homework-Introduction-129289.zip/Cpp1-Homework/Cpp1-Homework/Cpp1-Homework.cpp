#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
	string input;

	getline(cin, input);

	int upper = 0;
	int lower = 0;
	int other = 0;

	int i = 0;
	while(input[i])
	{
		char currentChar = input.at(i);

		if (isupper(currentChar))
		{
			upper++;
		}
		else if (islower(currentChar))
		{
			lower++;
		}
		else other++;

		i++;
	}

	cout << "Upper: ";
	cout << upper << endl;
	cout << "Lower: ";
	cout << lower << endl;
	cout << "Other: ";
	cout << other << endl;

    return 0;
}

