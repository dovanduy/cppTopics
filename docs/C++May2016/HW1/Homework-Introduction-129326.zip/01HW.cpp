#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>


using namespace std;

int main()
{
	string input;
	int lowercase = 0;
	int uppercase = 0;
	int spacial = 0;
	int digit;
	int count;
	char special;


	cin >> input;

	for (count = 0; count < input.size(); count++)
	{
		if (islower(input[count]))
			lowercase++;

		if (isupper(input[count]))
			uppercase++;	
	}
	cout << "lowercase:" << lowercase << endl;
	cout << "uppercase:" << uppercase << endl;

	cout << "other:" << input.size() - (uppercase + lowercase) << endl;
	return 0;
}
