// 02HW.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include <string>
#include <sstream>

using namespace std;

int main()
{
	string input;
	double a;
	double b;
	double pi = 3.14;
	double area;
	cout << "Enter the figure which you are going to calculate the area: triangle, square, rectangle or circle " << endl;
	cin >> input;
	if (input == "triangle")
	{
		cout << "enter the height of the triangle:" << endl;
		cin >> a;
		cout << "enter the side lenght of the triangle:" << endl;
		cin >> b;
		area = (b*a) / 2;
		cout << "triangle area:" << area << endl;
	}
	else if (input == "square")
	{
		cout << "enter the lenght of the side of the square:" << endl;
		cin >> a;
		area = a*a;
		cout << "square area:" << area << endl;
	}
	else if (input =="rectangle")
	{
		cout << "enter the lenght of the both sides of the rectangle:" << endl;
		cin >> a;
		cin >> b;
		area = a*b;
		cout << "rectangle area:" << area << endl;
	}
	else if (input=="circle")
	{
		cout << "enter the radius of the circle:" << endl;
		cin >> a;
		area = pi*a*a;
		cout << "circle area:" << area << endl;
	}
    return 0;
}

