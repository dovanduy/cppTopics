﻿ФАЙЛ				Описание
----				--------
02.CPP-OOP-Homework.pdf		Условия на двете задачи
Building.h			Клас "Building"
hw2-problem-1.cpp		Решение на първа задача от второ домашно
hw2-problem-2.cpp		Решение на втора задача от второ домашно
ReadMe1st.txt			Този файл

За да компилирате решенията от cpp файловете,
необходимо е файлът Building.h да е в същата директория.

Използван софтуер:
Win 10 Ent 64 bit;
ISO C++11, GCC 4.9.2 64 bit Release;
Dev-C++ 5.11, Build 27-Apr-2015.
