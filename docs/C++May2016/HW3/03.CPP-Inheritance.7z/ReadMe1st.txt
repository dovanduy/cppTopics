﻿ФАЙЛ					Описание
----					--------
03.CPP-Inheritance-Homework.pdf		Условие на задачата
main.cpp				Решение на задачата
EduPersons.h				Клас "EduPersons", за човешката активност в учебния процес
Courses.h				Клас "Courses"
Courses.cpp				Тестов пример за класа Courses
Persons.h				Клас "Persons"
Persons.cpp				Тестов пример за класа Persons
ReadMe1st.txt				Този файл
*.dat					Текстови файлове с използваните Инфо-Масиви
persons.dat				Използва се от класа Persons и наследяващите го класове
courses.dat				Използва се от класа Courses и наследяващите го класове
students.dat				Използва се от класа EduPersons
teachers.dat				Използва се от класа EduPersons
guestTeachers.dat			Използва се от класа EduPersons

За да компилирате cpp файловете,
необходимо е файловете *.h да са в същата директория.

За да стартирате компилацията си,
желателно е файловете *.dat да са в същата директория.

Използван софтуер:
Win 10 Ent 64 bit;
ISO C++11, GCC 4.9.2 64 bit Release;
Dev-C++ 5.11, Build 27-Apr-2015.
