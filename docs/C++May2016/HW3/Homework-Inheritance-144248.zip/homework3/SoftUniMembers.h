#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Human
{
public:	
	int ID;
	string name;
	string currentCourse;
	inline ~Human(){};
	inline Human(){};	
	
};

class Student:private Human
{
public: 
	float averageMark;
	int currentPoints;
	bool isFirstCourse;
	inline ~Student(){};
	inline Student(){};
	inline int GetID()
	{
		return ID;
	}
	inline static void GetStudentInfo(Student &aStudent)
	{
		cout<<"The student's ID is"<<aStudent.ID<<endl;
		cout<<"The student's name is "<<aStudent.name<<endl;
		cout<<"The student's mark is "<<aStudent.averageMark<<endl;
		cout<<"The student's points in the current cours are "<<aStudent.currentPoints<<endl;
		cout<<"The student's current course is "<<aStudent.currentCourse<<endl;
		
			
	}
	inline Student(int id,string name,string currentCource,float Mark,int points)
	{
		this->ID=id;
		this->name=name;
		this->currentCourse=currentCourse;
		averageMark=Mark;
	
	}

};

class Teacher:private Human
{
public:
	float monthlySalary;
	int experienceSU;
	inline Teacher();
	inline Teacher(int id, string Name, string CurrentCourse,float Salary,float experience)
	{
	   this->ID=id;
	   this->name=Name;
	   this->currentCourse=CurrentCourse;
	   monthlySalary=Salary;
	   experienceSU=experience;
	}
	inline int GetID()
	{ 
		return ID;
	}
	inline static void GetTeacherInfo(Teacher &aTeacher)
	{
		cout<<"Teacher's ID is "<<aTeacher.ID<<endl;
		cout<<"Teacher's name is "<<aTeacher.name<<endl;
		cout<<"Teacher's current course is "<<aTeacher.currentCourse<<endl;
		cout<<"Teacher's monthly salary is "<<aTeacher.monthlySalary<<endl;
		cout<<"Teacher's experience is "<<aTeacher.experienceSU<<endl;
	}
	inline ~Teacher(){};
};

class GuestTeacher:private Human
{
public:
	float salaryForCourse;
	inline GuestTeacher(){};
	inline ~GuestTeacher(){};
	inline GuestTeacher(int id, string Name,string CurrentCourse,float SalaryForCourse)
	{
		this->ID=id;
		this->name=Name;
		this->currentCourse=CurrentCourse;
		salaryForCourse=SalaryForCourse;
	}
	int GetID()
	{
		return ID;
	}
	inline static void GetGuestTeacherInfo(GuestTeacher &aGTeacher)
	{
		cout<<"Guest teacher's ID is "<<aGTeacher.ID<<endl;
		cout<<"Guest teacher's name is "<<aGTeacher.name<<endl;
		cout<<"Guest teacher's current course "<<aGTeacher.currentCourse<<endl;
		cout<<"Guest teacher's salary for course "<<aGTeacher.salaryForCourse<<endl;
		
	}
};
