#include "SoftUniMembers.h"

enum Options
{
	GetDataForStudent,
	GetDataForTeacher,
	GetDataForGuestTeacher,
	SetDataForStudent,
	SetDataForTeacher,
	SetDataForGuestTeacher,
};
    
int main(int argc, char** argv) 
{
 	int chosenOption;
 	int index;
	vector<Student> Students;
    Students.push_back(Student(0,"Ivan Petkov","C++ fundamentals",5.30,90));
 	
 	vector<Teacher> teachers;
 	teachers.push_back(Teacher(0,"Svetlin Nakov","Intro progamming",700,1000));
 	vector<GuestTeacher> gTeachers;
 	gTeachers.push_back(GuestTeacher(0,"Martin Kuvandzhiev","C++ may",1200));
 	Start:
	cout<<"Choose option"<<endl;
 	cout<<"0.Get data for students"<<endl;
 	cout<<"1.Get data for teachers"<<endl;
 	cout<<"2.Get data for guest teachers"<<endl;
 	cout<<"3.Set new student"<<endl;
 	cout<<"4.Set new teacher"<<endl;
 	cout<<"5.Set new guest teacher"<<endl;
 	cout<<"Exit"<<endl;
 
	 cin>>chosenOption ;
	 cin.ignore();
	 switch(chosenOption)
 	{
 		case GetDataForStudent:
 			{
 				cout<<"Enter student's ID ";
 				int ID;
 				cin>>ID;
 				cout<<endl;
 				index=0;
 				for(index=0;index<Students.size();index++)
				 {if(Students.at(index).GetID()==ID)
				 	{
				 		Student::GetStudentInfo(Students.at(index));
				 		goto Start;
				 	}
				 }
				 cout<<"There is not a student with ID:"<<ID<<endl;
				 goto Start;
 				
			}
		case GetDataForTeacher:
		{
			cout<<"Enter teacher's ID  ";
			int ID;
			cin>>ID;
			cout<<endl;
			index=0; 
			for(index=0;index<teachers.size();index++)
			{
				if(teachers.at(index).GetID()==ID)
			 	{
					Teacher::GetTeacherInfo(teachers.at(index));
					goto Start;
				}
				
			}
			cout<<"There is not a teacher with ID:"<<ID<<endl;
				goto Start;	
		}
		
		case GetDataForGuestTeacher:
		{
			index=0;
			int ID;
			cin>>ID;
			cout<<endl;
			for(index=0;index<gTeachers.size();index++)
			{
				if(gTeachers.at(index).GetID()==ID)
				{
					GuestTeacher::GetGuestTeacherInfo(gTeachers.at(index));
					goto Start;
				}
			} cout<<"There is not a guest teacher with ID: "<<ID<<endl;
		}
		
		case SetDataForStudent:
		{
			int ID;
			if(Students.size()==0) ID=0;
			else
			{
				ID= Students.size();
			}
			cout<<"ID: "<<ID<<endl;
			cout<<"Enter student's name ";
			string bufferName;
			getline(cin,bufferName); 
			cin.ignore();
			cout<<endl;
			cout<<"Enter student's current course ";
			string bufCourse;
			getline(cin,bufCourse);
			cin.ignore();
			cout<<endl;
			cout<<"Enter student's current points";
			int bufPoints;
			cin>>bufPoints;
			cin.ignore();
			cout<<endl;
			cout<<"Is this student's first year? (answer yes or no)"<<endl;
			string answer;
			int averageMark;
			cin>>answer;
			cin.ignore();
			if(answer=="yes")
			{
		    	 averageMark=0;
			  
			}
			else 
			{
				cout<<"Enter average mark";
				cin>>averageMark;
				cin.ignore();
				cout<<endl;			
			}
			Students.push_back(Student(ID,string(bufferName),bufCourse,averageMark,bufPoints));
			goto Start;
	
		}
		
		case SetDataForTeacher:
		{
			
			int ID;
			if(teachers.size()==0) ID=0;
			else
			{
				ID= teachers.size();
			}
			cout<<"Enter teacher's name "<<endl;
			string bufName;
			getline(cin,bufName);
			cout<<endl;
			cout<<"Enter teacher's current course "<<endl;
			string bufCourse;
			getline(cin,bufCourse);
			cout<<endl;
			cout<<"Enter teacher's salary "<<endl;
			float salary;
			cin>>salary;
			cout<<"Enter teacher's experience (days)"<<endl;
			int experience;
			cin>>experience;
			teachers.push_back(Teacher(ID,bufName,bufCourse,salary,experience));
			goto Start;
		}
		
		case SetDataForGuestTeacher:
		{	
			int ID;
			if(gTeachers.size()==0) ID=0;
			else
			{
				ID= gTeachers.size();
			}
        	cout<<"Enter guest teacher's name "<<endl;
			string bufName;
			getline(cin,bufName);
			cout<<endl;
			cout<<"Enter guest teacher's current course "<<endl;
			string bufCourse;
			getline(cin,bufCourse);
			cout<<endl;
			cout<<"Enter teacher's salary per course"<<endl;
			float salary;
			gTeachers.push_back(GuestTeacher(ID,bufName,bufCourse,salary));
			goto Start;		
		}
		default:
		{
			break;
		}	
	}
 	system("PAUSE");
	return 0;
}
