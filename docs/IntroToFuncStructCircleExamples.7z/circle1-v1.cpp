// Input: point A(ax, ay)
// Output: 
//	Yes  point A is on a circle K(O, 1)
//	No  point A is not on a circle K(O, 1)
#include <iostream>
using namespace std;
main()
{
	double ax, ay;
	cin >>ax >>ay;
	if (1 == ax*ax+ay*ay)
		cout <<"Yes";
	else
		cout <<"No";
}

