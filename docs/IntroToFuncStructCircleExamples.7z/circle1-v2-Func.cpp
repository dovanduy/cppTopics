// Input: point A(ax, ay)
// Output: 
//	Yes  point A is on a circle K(O, 1)
//	No  point A is not on a circle K(O, 1)
#include <iostream>
using namespace std;
bool isOnCircle (double x, double y, double r=1)
{
	return (r*r == x*x + y*y) ;
}
main()
{
	double ax, ay;
	cin >>ax >>ay;
	if (isOnCircle(ax, ay))
		cout <<"Yes";
	else
		cout <<"No";
}

