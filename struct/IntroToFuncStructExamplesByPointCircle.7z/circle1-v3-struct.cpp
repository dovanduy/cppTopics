// Input: point A(ax, ay)
// Output: 
//	Yes  point A is on a circle K(O, 1)
//	No  point A is not on a circle K(O, 1)
#include <iostream>
using namespace std;

struct Point { // user defined type Point
	double x ;
	double y ;
};

bool isOnCircle (Point t, double r=1)
{
	return (r*r == t.x*t.x + t.y*t.y) ;
}
main()
{
	Point A; // variable A of type Point
	cin >>A.x >>A.y ;
	if (isOnCircle(A))
		cout <<"Yes";
	else
		cout <<"No";
}

