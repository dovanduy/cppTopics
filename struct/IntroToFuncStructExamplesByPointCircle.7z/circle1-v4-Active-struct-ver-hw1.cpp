// Input: point A(ax, ay)
// Output: 
//	Yes  point A is on a circle K(O, 1)
//	No  point A is not on a circle K(O, 1)
#include <iostream>
#include <cmath>
using namespace std;

struct Point { // Point is an user defined type
// x, y, isOnCircle are local names,
// i.e. the names are valid inside a block only.
	double x ;
	double y ;
	// func belongs to struct
	// now struct is active data
	// data + functions
	bool isOnCircle (double r=1)
{
	return (r*r == x*x + y*y) ;
}

	double distance (Point Point2)
{ // from current Point to Point2
	return sqrt((x-Point2.x)*(x-Point2.x) 
	+ (y-Point2.y)*(x-Point2.x)) ;
}

};


main()
{
	Point B, C; // variable A of type Point
	cin >>B.x >>B.y >>C.x >>C.y; 
// to print a distance betweeen B and C
	cout <<B.distance(C) ;
} // HW: 
// 1. to define a new func Distance (Point1, Point2)
// 2. to define circle struct

