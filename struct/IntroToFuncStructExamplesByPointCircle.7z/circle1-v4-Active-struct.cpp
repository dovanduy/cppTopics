// Input: point A(ax, ay)
// Output: 
//	Yes  point A is on a circle K(O, 1)
//	No  point A is not on a circle K(O, 1)
#include <iostream>
using namespace std;

struct Point { // Point is an user defined type
// x, y, isOnCircle are local names,
// i.e. the names are valid inside a block only.
	double x ;
	double y ;
	// func belongs to struct
	// now struct is active data
	// data + functions
	bool isOnCircle (double r=1)
{
	return (r*r == x*x + y*y) ;
}
};


main()
{
	Point B; // variable A of type Point
	cin >>B.x >>B.y ;
	if (B.isOnCircle()) // func call syntax
		cout <<"Yes";
	else
		cout <<"No";
} // HW: 
// 1. to define a new func Distance (Point1, Point2)
// 2. to define circle struct

