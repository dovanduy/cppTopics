// Input: point A(ax, ay)
// Output: 
//	Yes  point A is on a circle K(O, 1)
//	No  point A is not on a circle K(O, 1)
#include <iostream>
using namespace std;

// from struct to class+public
// the public is default about struct

class Point { // Point is an user defined type
// x, y, isOnCircle are local names,
// i.e. the names are valid inside a block only.
	public: 
	// public means every one can use it
	double x ; 
	double y ;
	// func belongs to struct
	// now struct is active data
	// data + functions
	bool isOnCircle (double r=1)
{
	return (r*r == x*x + y*y) ;
}
};

main()
{ // it is a first OOP example
	Point C; // object C of class Point
	cin >>C.x >>C.y ;
	if (C.isOnCircle()) // OOP func call syntax
		cout <<"Yes";
	else
		cout <<"No";
} // HW: to define circle struct

