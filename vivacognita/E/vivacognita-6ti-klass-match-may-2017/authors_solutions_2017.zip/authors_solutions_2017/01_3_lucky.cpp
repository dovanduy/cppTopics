#include<iostream>
using namespace std;
int main ()
{ int n,s=0,p,q,r,t;
  char c1,c2,c3,c4,c5,c6,c7,c8;
  int x3,x4,x5,x6;
  cin.get(c1);
  cin.get(c2);
  cin.get(c3);
  cin.get(c4);
  cin.get(c5);
  cin.get(c6);
  cin.get(c7);
  cin.get(c8);
  p=(char)c1; r=(char)c7;
  q=(char)c2; t=(char)c8;
  x3=c3-'0';
  x4=c4-'0';
  x5=c5-'0';
  x6=c6-'0';
  s=x3*x4*x5*x6; 
  n=(p+q+r+t)/10;
  if(s==n)cout<<"Yes"<<" "<<s; 
  else cout<<"No";
  cout<<endl;
  return 0;
}
