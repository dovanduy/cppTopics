#include <iostream>
using namespace std;
int a[10]; 
int main()
{int n,m,i,j,k;
 int max;
 cin>>n>>m;
 for (i=1;i<=n;i++)
    for (j=1;j<=m;j++)
        {k=i*j;
         while (k > 0)
            {a[k%10]++;
             k=k/10;
            }
        }
 max=a[0];k=0;  
 for (i=1;i<=9;i++) 
     if (max<a[i]) {max=a[i];k=i;}
 cout<<k<<" "<<max<<endl;
 return 0;
}

  
