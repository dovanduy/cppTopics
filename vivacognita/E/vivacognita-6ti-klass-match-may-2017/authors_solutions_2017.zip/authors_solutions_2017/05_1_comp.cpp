#include<iostream>
using namespace std;

const int M=51;
const int N=51;

int a[M][N];
int m,n;

int di[]={-1,1,0, 0};
int dj[]={ 0,0,1,-1};


void show()
{
  for(int i=1;i<=m;i++)
  {
   for(int j=1;j<=n;j++) cout << a[i][j];
   cout << endl;
  }
  cout << endl;
}


int c=1;

bool spread()
{ bool b=false;
  for(int i=1;i<=m;i++)
  for(int j=1;j<=n;j++)
  if(a[i][j]==0)
   { for(int t=0;t<=3;t++)
     { int i0=i+di[t]; int j0=j+dj[t];
       if(i0>0 && i0<=m && j0>0 && j0<=n)
       if(a[i0][j0]==c) {a[i][j]=c; b=true;}
     }
    }
  return b;
}


void wave()
{
  for(int i=1;i<=m;i++)
  for(int j=1;j<=n;j++)
  {
    if(a[i][j]==0)
    {
      c++;
      a[i][j]=c;
      while(spread());
    }
  }
}

int main()
{
  cin >> m >> n;
  for(int i=1;i<=m;i++)
  for(int j=1;j<=n;j++)
  {
    char ch;
    cin >> ch;
    if(ch=='1') a[i][j]=1;
  }


  wave();


  cout << c-1 << endl;

}
