#include<iostream>
#include<algorithm>
using namespace std;

const int N=10;

int x[2][N], y[2][N];
int n;
int X[2*N], Y[2*N];
int k;


int inside(int p, int ax, int ay)
{
  if(    x[0][p]< ax && ax < x[1][p]
      && y[0][p]< ay && ay < y[1][p])
  return 1;
  return 0;
}

int main()
{
  cin >> n;
  for(int i=0;i<n;i++)
  {
    cin >> x[0][i] >> y[0][i] >> x[1][i] >> y[1][i];
    x[0][i] = 2*x[0][i];
    y[0][i] = 2*y[0][i];
    x[1][i] = 2*x[1][i];
    y[1][i] = 2*y[1][i];
    if(x[0][i]>x[1][i]) swap(x[0][i],x[1][i]);
    if(y[0][i]>y[1][i]) swap(y[0][i],y[1][i]);

    X[k]=x[0][i]; Y[k]=y[0][i]; k++;
    X[k]=x[1][i]; Y[k]=y[1][i]; k++;
  }
  sort(X,X+k);
  sort(Y,Y+k);

  for(int i=1;i<k;i++)
  for(int j=1;j<k;j++)
  {
    int m=0;
    for(int p=0;p<n;p++) m += inside(p,(X[i-1]+X[i])/2, (Y[j-1]+Y[j])/2);
    if(m==n)
    {
      cout << (X[i]-X[i-1])*(Y[i]-Y[i-1])/4 << endl;
      return 0;
    }

  }

  cout << 0 << endl;
}
