//solve ax+by=c with min x+y>=0.

#include<iostream>
#include<cmath>
#include<climits>
using namespace std;

typedef long long int INT;

INT a,b,c;


INT euclid(INT a, INT b, INT &x, INT &y)
{
  INT x1=1, y1=0, x2=0, y2=1;
  while(a!=b)
   if(a>b)
    {a=a-b;x1=x1-x2;y1=y1-y2;}
   else
    {b=b-a;x2=x2-x1;y2=y2-y1;}

  x=x1; y=y1;
  return a;
}

int main()
{
  cin >> a >> b >> c;
  INT d,x,y;
  d=euclid(a,b,x,y);

  if(!(c%d==0)) {cout << "No solution" << endl; return 0;}
  INT r=c/d;

  x=r*x;
  y=r*y;

  long double f=-(long double)(x+y)/((b-a)/d);
  INT t1 = (int)(f)-2;

  INT v=LLONG_MAX;
  INT t0;
  for(INT t=t1; t<=t1+3; t++)
  {
   INT s=(x+y)+t*(b-a)/d;
   if(s>=0) if(s<v) {v=s; t0=t;}
  }
  cout << v << endl;
}
