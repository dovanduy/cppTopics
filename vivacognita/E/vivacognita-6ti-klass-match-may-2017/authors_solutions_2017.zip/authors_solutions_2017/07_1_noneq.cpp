#include <iostream>
using namespace std;

int base;
int c[36];

bool ok(int x)
{
  for(int i=0;i<base;i++) c[i]=0;

  while(x>0)
  { int d = x % base;
    if(c[d]==1) return false;
    c[d]=1;
    x = x / base;
  }

  return true;
}

int main()
{ int a,b;

  cin >> a >> b >> base;

  int cnt=0;

  for(int x=a; x<=b; x++)
    if(ok(x)) cnt++;

  cout << cnt << endl;

  return 0;
}

