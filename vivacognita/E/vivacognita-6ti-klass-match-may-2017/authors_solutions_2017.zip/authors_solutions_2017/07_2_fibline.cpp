#include<iostream>
using namespace std;

const int M=10000;

int a[M];int na;
int b[M];int nb;
int c[M];int n;

void show()
{
  for(int i=n;i>=0;i--) cout << c[i];
  cout << endl;
}

void copyba()
{
  na=nb;
  for(int i=0;i<=nb;i++) a[i]=b[i];
}

void copycb()
{
  nb=n;
  for(int i=0;i<=nb;i++) b[i]=c[i];
}

void sum()
{
  n=na;
  if(na<nb)
    {n=nb;for(int i=na+1;i<=nb;i++)  a[i]=0;}
  else if(nb<na)
    {n=na; for(int i=nb+1;i<=na;i++) b[i]=0;}

  int p=0;
  for(int i=0;i<=n;i++)
    { c[i]=a[i]+b[i]+p;
      p=0;
      if(c[i]>=10){p=1;c[i]=c[i]-10;}
    }
   if(p==1){n++;c[n]=1;}
}

int main()
{
  int k;
  cin >> k;
  na=0; a[0]=1;
  nb=0; b[0]=1;
  int L=2;
  int nf=2;
  while(k>L)
  {
    sum();
    nf++;
    L = L + n + 1;
    copyba();
    copycb();
  }
  int j=0;
  while(k<L) {L--; j++;}
  cout << c[j] << endl;
}


