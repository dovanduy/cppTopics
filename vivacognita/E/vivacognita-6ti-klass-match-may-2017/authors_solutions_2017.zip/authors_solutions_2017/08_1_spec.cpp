#include<iostream>
#include<set>
using namespace std;

set<int> s;
set<int> r;
int n;

int main()
{
  cin >> n;
  int a=1;
  int b;
  s.insert(1);

  for(int i=2;i<=n;i++)
  {
    if(a>i) b=a-i; else b=a+i;
    if(s.count(b)==0) s.insert(b);
    else r.insert(b);
    a=b;
  }
  cout << r.size() << endl;
}

