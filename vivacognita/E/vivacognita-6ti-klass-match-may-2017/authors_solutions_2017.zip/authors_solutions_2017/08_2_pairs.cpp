#include<iostream>
#include<set>
using namespace std;


int a[7002];
bool p[202][202];
int n;

int main()
{

  cin >> n;
  for(int i=0;i<n;i++) cin >> a[i];



  for (int i=0; i<n; i++)
  for (int j=i+1; j<n; j++)
    p[a[i]][a[j]]=1;

  int c=0;
  for(int i=1;i<=200;i++)
  for(int j=1;j<=200;j++)
   c += p[i][j];

  cout << c << endl;

}
