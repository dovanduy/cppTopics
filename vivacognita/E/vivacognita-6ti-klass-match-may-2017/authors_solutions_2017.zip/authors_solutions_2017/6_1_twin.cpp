// twin primes

#include<iostream>
#include<iomanip>
using namespace std;

const int N=100000000;
char a[N+2];
int n1, n2;

int main()
{
  cin >> n1 >> n2;

  int n=n2;
  for(int k=2;k<=n;k++)
  {
    if(a[k]==1) continue;
    int j=k+k;
    while(j<=n) {a[j]=1; j+=k;}
  }

 int c=0;

 for(int i=n1;i<=n2-2;i++)
    if((a[i]==0)&&(a[i+2]==0))  c++;

 cout << c << endl;

}
