#include<iostream>
using namespace std;

int main()
{
 int d,m,g;
 cin >> d >> m >> g;

 int p=31;
 if(m==2)
 { p=28;
  if(((g%4==0)&&(g%100!=0))||(g%400==0)) p=29;
 }
 else if(m==4||m==6||m==9||m==11)p=30;

 if(d<p) d++;
 else { d=1; if(m<12) m++; else {m=1; g++;} }
 cout << d << " " << m << " " << g << endl;
}
