#include<iostream>
#include<cmath>
using namespace std;

bool deliteli(int d,int m)
{ int br=0;
  for(int i=2;i<d;i++)
    if(d%i==0) br++;
  if(br==m) return 1;
  else return 0;
}
int main()
{ int n, m, a, i,k=0;
   cin>>n>>m;
   for(i=1;i<=n;i++)
   {
   cin>>a;
   if(deliteli(abs(a),m)) k++;
   }
   cout<<k<<endl;
}
