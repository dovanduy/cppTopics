#include<iostream>
using namespace std;

int main()
{
    int a;
    cin >> a;
    int x=a/10;
    cout << x/10 << endl;
    cout << x%10 << endl;
    cout << a%10 << endl;
}
