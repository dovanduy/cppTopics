#include <iostream>
using namespace std;

int main()
{
  int r2=0, r3=0, r5=0;
  int s=0;
  char c0, c;

  while(1)
  {
    cin >> c;
    if(c=='.') break;
    c0=c;
    s = s + ((int)c0-(int)'0');
  }

  int d=((int)c0-(int)'0');
  if(d%2==0) r2=1;
  if(s%3==0) r3=1;
  if(d%5==0) r5=1;

  cout << r2 << " " << r3 << " " << r5 << endl;
}
