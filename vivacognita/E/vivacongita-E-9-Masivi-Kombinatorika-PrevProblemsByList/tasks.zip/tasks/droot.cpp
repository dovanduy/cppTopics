#include<iostream>
#include<cstdio>
using namespace std;

long n, m, d, k, p, f, q;

main()
{
    cin>>n;
    d=n;
    while (d>9){
        m=d; d=0; q=10; k=1; p=0;
        while (m>0) {
            f=m%10; m/=10;
            if (f==q)k++;
            d+=f; p++;
            q=f;
        }
        if (k==p)d=f;
    }
    cout<<d<<endl;
}
