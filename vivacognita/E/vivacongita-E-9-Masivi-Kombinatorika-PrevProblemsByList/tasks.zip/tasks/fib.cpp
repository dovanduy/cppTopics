#include<iostream>
using namespace std;
int main()
{
  int n=0;
  char c;
  cin >> c;

  while(c!='.'){n++; cin >> c;}

  int f=1, f1=1, f2=1;
  int k=0;
  while(f<=n)
   {
     k++;
     f=f1+f2;f1=f2;f2=f;
   }
  cout << k << endl;
}
