#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
 long long c1, c2, c3, n1, n2, n3, s;
 cin>>c1>>c2>>c3>>n1>>n2>>n3>>s;

 if(c1>c2) swap(c1,c2), swap(n1,n2);
 if(c2>c3) swap(c2,c3), swap(n2,n3);
 if(c1>c2) swap(c1,c2), swap(n1,n2);

 long long r, t, tmp;
 if(c1!=0) tmp=s/c1; else tmp=n1;
 r = min(n1, tmp);
 s-=r*c1;

 if(c2!=0) tmp=s/c2; else tmp=n2;
 t = min(n2, tmp);
 s-= t*c2;
 r += t;

 if(c3!=0) tmp=s/c3; else tmp=n3;
 r += min(n3, tmp);
 cout<<r<<endl;
}


