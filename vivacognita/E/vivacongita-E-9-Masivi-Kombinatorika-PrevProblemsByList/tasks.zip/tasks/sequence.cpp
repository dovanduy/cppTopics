#include<iostream>
using namespace std;
int main()
{
    long long t, v, maxv;
    int n, c, maxc=1;
    cin>>n;
    cin>>t; c=1; maxv=t;
    for(int i=1;i<n;i++)
    { cin>>v;
      if(v==t) c++;
      else
      { if (c>maxc) {maxc=c;maxv=t;}
        t=v;c=1;
      }
    }
    if (c>maxc) {maxc=c;maxv=t;}
    cout<<maxv<<endl;
}
